# WeatherAPI-with-Openweathermap
Agrivision mobile app API for Bangkit capstone project

npm install

node src/index.js
